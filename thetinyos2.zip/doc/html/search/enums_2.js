var searchData=
[
  ['phil_602',['PHIL',['../symposium_8h.html#a9fced5fb7d50a8fa2e8ae45b0cae3520',1,'symposium.h']]],
  ['pid_5fstate_5fe_603',['pid_state_e',['../group__proc.html#ga4f133ac5f9b2ca9c1446889baee1dc05',1,'kernel_proc.h']]]
];
