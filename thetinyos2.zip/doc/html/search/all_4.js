var searchData=
[
  ['dcb_72',['DCB',['../group__dev.html#ga5b4de7b0c72db6219c5a6dda2466181f',1,'DCB():&#160;kernel_dev.h'],['../group__rlists.html#ga5b4de7b0c72db6219c5a6dda2466181f',1,'DCB():&#160;util.h']]],
  ['default_5ftimeout_73',['DEFAULT_TIMEOUT',['../group__Testing.html#gaad2dd72565852b91c809cd4685833b17',1,'unit_testing.h']]],
  ['description_74',['description',['../structTest.html#a294ca3f1114240c908f66216afcad783',1,'Test']]],
  ['dev_5ffops_75',['dev_fops',['../structdevice__control__block.html#a2945d5da96f40ff7fae94e295624a7c7',1,'device_control_block']]],
  ['dev_5fmax_76',['DEV_MAX',['../group__dev.html#gga879ceac20e83b2375e5b49f4379b0c90a4d07dfbc7e68d26e2d92773a37381ce7',1,'kernel_dev.h']]],
  ['dev_5fnull_77',['DEV_NULL',['../group__dev.html#gga879ceac20e83b2375e5b49f4379b0c90a8ca9ed7c2fc080b6706582ccf828b08f',1,'kernel_dev.h']]],
  ['dev_5fserial_78',['DEV_SERIAL',['../group__dev.html#gga879ceac20e83b2375e5b49f4379b0c90adb43c91cf279ccd4510abaed9425bacc',1,'kernel_dev.h']]],
  ['device_5fcontrol_5fblock_79',['device_control_block',['../structdevice__control__block.html',1,'']]],
  ['device_5fno_80',['device_no',['../group__dev.html#ga0808cf584a510e0eff6908a5313ce296',1,'device_no(Device_type major):&#160;kernel_dev.c'],['../group__dev.html#ga0808cf584a510e0eff6908a5313ce296',1,'device_no(Device_type major):&#160;kernel_dev.c']]],
  ['device_5fopen_81',['device_open',['../group__dev.html#ga6d8e08550640c9819aa07b6bba9fa6ed',1,'device_open(Device_type major, uint minor, void **obj, file_ops **ops):&#160;kernel_dev.c'],['../group__dev.html#ga6d8e08550640c9819aa07b6bba9fa6ed',1,'device_open(Device_type major, uint minor, void **obj, file_ops **ops):&#160;kernel_dev.c']]],
  ['device_5ftype_82',['Device_type',['../group__dev.html#ga879ceac20e83b2375e5b49f4379b0c90',1,'kernel_dev.h']]],
  ['devices_83',['Devices',['../group__dev.html',1,'']]],
  ['devnum_84',['devnum',['../structdevice__control__block.html#a25d8f038a1c6d41f445d078276117fba',1,'device_control_block']]],
  ['dup2_85',['Dup2',['../group__syscalls.html#gacc048c60209e2dfb4b5cfc1c3f21aa88',1,'tinyos.h']]]
];
