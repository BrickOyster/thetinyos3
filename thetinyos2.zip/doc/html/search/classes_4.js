var searchData=
[
  ['file_5fcontrol_5fblock_344',['file_control_block',['../structfile__control__block.html',1,'']]],
  ['file_5foperations_345',['file_operations',['../structfile__operations.html',1,'']]]
];
