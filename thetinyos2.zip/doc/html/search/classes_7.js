var searchData=
[
  ['resource_5flist_5fnode_352',['resource_list_node',['../structresource__list__node.html',1,'']]]
];
