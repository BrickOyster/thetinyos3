var searchData=
[
  ['logrec_346',['logrec',['../structlogrec.html',1,'']]]
];
