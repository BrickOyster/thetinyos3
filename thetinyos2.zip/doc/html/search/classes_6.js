var searchData=
[
  ['pipe_5fs_347',['pipe_s',['../structpipe__s.html',1,'']]],
  ['process_5fcontrol_5fblock_348',['process_control_block',['../structprocess__control__block.html',1,'']]],
  ['process_5fthread_5fcontrol_5fblock_349',['process_thread_control_block',['../structprocess__thread__control__block.html',1,'']]],
  ['procinfo_350',['procinfo',['../structprocinfo.html',1,'']]],
  ['program_5farguments_351',['program_arguments',['../structprogram__arguments.html',1,'']]]
];
