var searchData=
[
  ['use_5fcolor_565',['use_color',['../structprogram__arguments.html#ae952a1ee415137013201280b500796c7',1,'program_arguments']]]
];
