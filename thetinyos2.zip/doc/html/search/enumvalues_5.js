var searchData=
[
  ['ici_618',['ICI',['../bios_8h.html#a137af7bce5ff764f5c0aa4550086deaaab4019255561cb4b48789d55c079e1709',1,'bios.h']]],
  ['idle_5fthread_619',['IDLE_THREAD',['../group__scheduler.html#gga18795bc1ab00161fc27ce34b1895fb03abc11b4e4eba50c875d7ed6bc34090dd3',1,'kernel_sched.h']]],
  ['init_620',['INIT',['../group__scheduler.html#gga6c969c169777f82c104cf73e501df70fa0cb1b2c6a7db1f1084886c98909a3f36',1,'kernel_sched.h']]]
];
