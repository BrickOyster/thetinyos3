var searchData=
[
  ['fcb_5fdecref_413',['FCB_decref',['../group__streams.html#ga26586eafc28dd1f2ac5bc7402922aa36',1,'FCB_decref(FCB *fcb):&#160;kernel_streams.c'],['../group__streams.html#ga26586eafc28dd1f2ac5bc7402922aa36',1,'FCB_decref(FCB *fcb):&#160;kernel_streams.c']]],
  ['fcb_5fincref_414',['FCB_incref',['../group__streams.html#ga409efca0b415dfdabe868c292d1daf66',1,'FCB_incref(FCB *fcb):&#160;kernel_streams.c'],['../group__streams.html#ga409efca0b415dfdabe868c292d1daf66',1,'FCB_incref(FCB *fcb):&#160;kernel_streams.c']]],
  ['fcb_5freserve_415',['FCB_reserve',['../group__streams.html#ga462269376de145171b87b7bc3036e4f8',1,'FCB_reserve(size_t num, Fid_t *fid, FCB **fcb):&#160;kernel_streams.c'],['../group__streams.html#ga462269376de145171b87b7bc3036e4f8',1,'FCB_reserve(size_t num, Fid_t *fid, FCB **fcb):&#160;kernel_streams.c']]],
  ['fcb_5funreserve_416',['FCB_unreserve',['../group__streams.html#gac44c094845a8d4e2e13f9df5b17274df',1,'FCB_unreserve(size_t num, Fid_t *fid, FCB **fcb):&#160;kernel_streams.c'],['../group__streams.html#gac44c094845a8d4e2e13f9df5b17274df',1,'FCB_unreserve(size_t num, Fid_t *fid, FCB **fcb):&#160;kernel_streams.c']]],
  ['fibo_417',['fibo',['../symposium_8h.html#a84513d2aec8501a26825e23f0e450ca5',1,'symposium.h']]],
  ['fidopen_418',['fidopen',['../tinyoslib_8h.html#a8f1a14eaa13a383f7c12be56abc4ff4d',1,'tinyoslib.c']]]
];
