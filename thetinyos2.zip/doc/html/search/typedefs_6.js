var searchData=
[
  ['rlnode_590',['rlnode',['../group__rlists.html#gaa74c0c2c42ee954a2bfc695845fff5e1',1,'util.h']]],
  ['rlnode_5fptr_591',['rlnode_ptr',['../group__rlists.html#gaae2ea9be18d20f0c80a62a2f8e2eed4d',1,'util.h']]]
];
