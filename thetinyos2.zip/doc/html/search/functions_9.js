var searchData=
[
  ['listen_437',['Listen',['../group__syscalls.html#ga9ff5bae3e7b9e5bbf5a788a5ff739bf7',1,'tinyos.h']]]
];
