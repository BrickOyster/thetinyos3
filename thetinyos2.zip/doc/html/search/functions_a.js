var searchData=
[
  ['msg_438',['MSG',['../group__Testing.html#ga2e36933a48fbca44bb782f881ddceb20',1,'unit_testing.h']]],
  ['mutex_5flock_439',['Mutex_Lock',['../group__syscalls.html#ga1140be44df71d39edaf6a7262fb763ca',1,'Mutex_Lock(Mutex *lock):&#160;kernel_cc.c'],['../group__syscalls.html#ga1140be44df71d39edaf6a7262fb763ca',1,'Mutex_Lock(Mutex *):&#160;kernel_cc.c']]],
  ['mutex_5funlock_440',['Mutex_Unlock',['../group__syscalls.html#ga0b98d0315d0931d0c28104c36dd559c9',1,'Mutex_Unlock(Mutex *lock):&#160;kernel_cc.c'],['../group__syscalls.html#ga0b98d0315d0931d0c28104c36dd559c9',1,'Mutex_Unlock(Mutex *):&#160;kernel_cc.c']]]
];
